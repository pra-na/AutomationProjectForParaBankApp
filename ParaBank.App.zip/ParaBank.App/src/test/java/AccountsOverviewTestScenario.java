
import java.util.Date;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import PomPages.LoginPage;
import PomPages.AccountsOverviewPage;

public class AccountsOverviewTestScenario extends BaseClass {
	LoginPage loginPage;
	AccountsOverviewPage accountOverViewPage;

	@BeforeClass
	public void browserOpen() {
		System.out.println("beforeclass");
		Date d = new Date();
		System.out.println("the test case executed at" + d);
		launchBrowser();
		windowMaximize();
		launchUrl("https://parabank.parasoft.com/parabank/openaccount.htm");
		loginPage = new LoginPage(driver);

		// Login

		loginPage.enterUsername("john");
		loginPage.enterPassword("demo");
		loginPage.clickLogin();
		accountOverViewPage = new AccountsOverviewPage(driver);

	}

	@Test
	public void verifyAccountsOverview() {
		accountOverViewPage.printAccountDetails();
	}

	@AfterClass
	public void closinBrowser() {
		closeEntireBrowser();
	}
}
