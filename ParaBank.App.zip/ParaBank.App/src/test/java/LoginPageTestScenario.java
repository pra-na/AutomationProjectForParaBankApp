
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import PomPages.LoginPage;

public class LoginPageTestScenario extends BaseClass {

	LoginPage loginPage;

	@BeforeClass
	public void browserOpen() {
		System.out.println("beforeclass");
		Date d = new Date();
		System.out.println("the test case executed at" + d);
		launchBrowser();
		windowMaximize();
		launchUrl("https://parabank.parasoft.com/parabank/overview.html");
		LoginPage loginPage = new LoginPage(driver);

	}

	/////////// TS_001 To check login with Valid user and password

	@Test
	@Parameters({ "username", "password" })
	public void tS_001_ValidloginTest(String username, String password) {
		loginPage.enterUsername(username);
		loginPage.enterPassword(password);
		loginPage.clickLogin();

		// To get the title of the page
		String actualTitle = driver.getTitle();
		String expectedTitle = "ParaBank | Accounts Overview";

		// validation using assertion
		Assert.assertEquals(actualTitle, expectedTitle, "Login succeeded with username: " + username);
		System.out.println("TS_001 executed");
	}

	///// TS_002 To check Login with invalide username and valid password

	@Test
	@Parameters({ "username", "password" })
	public void tS_002_inValidUsernameloginTest(String username, String password) {
		loginPage.enterUsername(username);
		loginPage.enterPassword(password);
		loginPage.clickLogin();

		// validation on username field error message
		boolean isErrorShown = loginPage.isErrorMessageDisplayed();
		Assert.assertTrue(isErrorShown, "Login should fail with invalid password for username: " + username);
		System.out.println("TS_002 executed");
	}

	////// TS_003 To check Login with valid username and Invalid password

	@Test
	@Parameters({ "username", "password" })
	public void tS_003_InvalidPasswordLoginTest(String username, String password) {
		loginPage.enterUsername(username);
		loginPage.enterPassword(password);
		loginPage.clickLogin();

		// Login page has a method that checks if an error is displayed
		if (loginPage.isErrorMessageDisplayed()) {
			System.out.println("Enter valid password");

		} else {
			System.out.println("loged in with invalid password");
		}

	}

	////// TS_003 To check Login with Empty fields of username and password

	@Test
	@Parameters({ "username", "password" })
	public void tS_004_EmptyFiledLoginTest(String username, String password) {
		loginPage.usernameField.clear();
		loginPage.passwordField.clear();
		loginPage.clickLogin();

		// Validation on empty fields of username and password
		boolean isErrorShown = loginPage.isErrorMessageDisplayed();
		Assert.assertTrue(isErrorShown, "Login failed with empty credentials");
		System.out.println("TS_004 executed");

	}

	////// TS_005 To check Login with Empty field of username

	@Test
	@Parameters({ "username", "password" })
	public void tS_005_EmptyFiledOfUsernameLoginTest(String username, String password) {
		loginPage.usernameField.clear();
		loginPage.enterPassword(password);
		loginPage.clickLogin();

		// Validation on Username field is Empty
		boolean isErrorShown = loginPage.isErrorMessageDisplayed();
		Assert.assertTrue(isErrorShown, "Login failed with empty field of Username");
		System.out.println("TS_005 executed");

	}

	////// TS_006 Verify login with EmtyfieldofPassword
	@Test
	@Parameters({ "username", "password" })
	public void ts_006_EmptyFieldOfPasswordLoginTest(String username, String password) {
		loginPage.enterUsername(username);
		loginPage.passwordField.clear();
		loginPage.clickLogin();

		// Assert that the error message is displayed
		Assert.assertTrue(loginPage.isErrorMessageDisplayed(), "Error message is not displayed.");

		// Validation on Password field is Empty
		// Assert that the error message text is as expected
		String expectedMessage = "Please enter a username and password.";
		String actualmess = loginPage.errorMessage.getText();
		Assert.assertEquals(actualmess, expectedMessage, "Unexpected error message.");
	}

	// TS_007 verify password field is masking or not
	@Test
	@Parameters({ "username", "password" })

	public void ts_007_PsswordFieldMasking(String username, String password) {
		loginPage.enterUsername(username);
		loginPage.enterPassword(password);

		String fieldType = loginPage.passwordField.getAttribute("type");
		String fieldValue = loginPage.passwordField.getAttribute("value");

		// Assert that the field type is 'password'
		// Assert.assertEquals(fieldType, "password", "Password field is not masked.");
		if (fieldValue.isEmpty()) {
			System.out.println("enter value in password field to validate");

		} else if ("password".equalsIgnoreCase(fieldType)) {
			System.out.println("Password field is masked correctly.");
		} else {
			System.out.println("Password field is not masked.");
		}
	}

	@AfterClass
	public void closinBrowser() {
		closeEntireBrowser();
	}
}
