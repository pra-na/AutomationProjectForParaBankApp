import org.testng.annotations.Test;

import BaseClass.BaseClass;
import PomPages.LoginPage;
import PomPages.TransferFundsPage;

import org.testng.annotations.BeforeClass;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TransferFundsTestScenario extends BaseClass {

	LoginPage loginPage;
	TransferFundsPage transferFundsPage;

	@BeforeClass
	public void browserOpen() {
		System.out.println("beforeClass");
		Date d = new Date();
		System.out.println("the test case executed at" + d);

		launchBrowser();
		windowMaximize();
		launchUrl("http://parabank.parasoft.com/parabank/index.htm");
		loginPage = new LoginPage(driver);
		loginPage.enterUsername("john");
		loginPage.enterPassword("demo");
		loginPage.clickLogin();
		transferFundsPage = new TransferFundsPage(driver);
	}

	@Test(priority = 1)
	public void testFundTransferBetweenValidAccounts() {
		// Navigate to Transfer Funds page
		transferFundsPage.transferFundsLink.click();

		transferFundsPage.enterAmount("100");
		transferFundsPage.selectFromAccount("13344");
		transferFundsPage.selectToAccount("13344");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement transferButton = wait
				.until(ExpectedConditions.elementToBeClickable(transferFundsPage.transferButton));
		transferButton.click();

		String confirmation = transferFundsPage.getSuccessMessage();
		System.out.println(confirmation);
		Assert.assertTrue(confirmation.contains("Transfer Complete"), "Transfer failed!");
	}

	@Test
	public void testEmptyAmount() {
		// Navigate to Transfer Funds page
		transferFundsPage.transferFundsLink.click();
		transferFundsPage.enterAmount("");
		transferFundsPage.selectFromAccount("13344");
		transferFundsPage.selectToAccount("13344");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement transferButton = wait
				.until(ExpectedConditions.elementToBeClickable(transferFundsPage.transferButton));
		transferButton.click();

		String errorMessage = transferFundsPage.getErrorMessage();
		System.out.println(errorMessage);
		Assert.assertTrue(errorMessage.contains("Error"), "Transfer is successed");
	}

	@AfterClass
	public void closinBrowser() {
		closeEntireBrowser();
	}
}
