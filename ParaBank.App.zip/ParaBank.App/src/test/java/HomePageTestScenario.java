
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import PomPages.HomePage;
import PomPages.LoginPage;

public class HomePageTestScenario extends BaseClass {

	public LoginPage loginPage;
	public HomePage homepage;

	@BeforeClass
	public void browserOpen() {
		System.out.println("beforeClass");
		Date d = new Date();
		System.out.println("the test case executed at" + d);

		launchBrowser();
		windowMaximize();
		launchUrl("http://parabank.parasoft.com/parabank/index.htm");
		loginPage = new LoginPage(driver);
//		loginPage.enterUsername("john");
//		loginPage.enterPassword("dem");
		loginPage.clickLogin();
		homepage = new HomePage(driver);
	}

	@Test
	public void verifyHomePageLoads() {

		String title = driver.getTitle();
		Assert.assertTrue(driver.getTitle().contains("ParaBank"), "Title does not contain 'ParaBank'");
	}

	@Test
	public void verifyLoginFormElements() {

		Assert.assertTrue(loginPage.usernameField.isDisplayed(), "Username field not displayed");
		Assert.assertTrue(loginPage.passwordField.isDisplayed(), "Password field not displayed");
		Assert.assertTrue(loginPage.loginButton.isDisplayed(), "Login button not displayed");
	}

	@Test
	public void verifyNavigationLinks() {
		String[] linkTexts = { "About Us", "Services", "Products", "Locations", "Admin Page" };

		for (String linkText : linkTexts) {
			try {
				WebElement link = driver.findElement(By.linkText(linkText));
				assert link.isDisplayed() : "Link not visible: " + linkText;
				System.out.println("Visible: " + linkText);
			} catch (Exception e) {
				System.out.println("Not found or not visible: " + linkText);
			}
		}

	}

	@AfterClass
	public void closinBrowser() {
		closeEntireBrowser();
	}
}
