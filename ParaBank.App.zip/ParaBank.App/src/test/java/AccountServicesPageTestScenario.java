
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import BaseClass.BaseClass;
import PomPages.AccountServicesPage;
import PomPages.LoginPage;

public class AccountServicesPageTestScenario extends BaseClass {

	LoginPage loginPage;
	AccountServicesPage accountServicesPage;

	@BeforeClass
	public void browserOpen() {
		System.out.println("beforeclass");
		Date d = new Date();
		System.out.println("the test case executed at" + d);

		launchBrowser();
		windowMaximize();
		launchUrl("https://parabank.parasoft.com/parabank/overview.html");
		loginPage = new LoginPage(driver);
		loginPage.enterUsername("john");
		loginPage.enterPassword("demo");
		loginPage.clickLogin();
		accountServicesPage = new AccountServicesPage(driver);

	}

	@Test
	public void verifyAccountServicesLinks() {
		String[] expectedLinks = { "Open New Account", "Accounts Overview", "Transfer Funds", "Bill Pay",
				"Find Transactions", "Update Contact Info", "Request Loan", "Log Out" };

		for (String linkText : expectedLinks) {
			try {
				WebElement link = driver.findElement(By.linkText(linkText));
				Assert.assertTrue(link.isDisplayed(), linkText + " is not visible.");
				System.out.println("Visible: " + linkText);
			} catch (Exception e) {
				System.out.println(" Not found or not visible: " + linkText);
			}
		}
	}

	@AfterClass
	public void closinBrowser() {
		closeEntireBrowser();
	}

}
