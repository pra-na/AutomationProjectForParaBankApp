
import org.testng.annotations.Test;

import BaseClass.BaseClass;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import java.time.Duration;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import PomPages.LoginPage;
import PomPages.OpenNewAccountPage;

public class OpenNewAccountPageTestScenario extends BaseClass {

	LoginPage loginPage;
	OpenNewAccountPage openNewAccount;

	@BeforeClass
	public void browserOpen() {
		System.out.println("beforeclass");
		Date d = new Date();
		System.out.println("the test case executed at" + d);
		launchBrowser();
		windowMaximize();
		launchUrl("https://parabank.parasoft.com/parabank/openaccount.htm");
		loginPage = new LoginPage(driver);

		// Login

		loginPage.enterUsername("john");
		loginPage.enterPassword("demo");
		loginPage.clickLogin();

		openNewAccount = new OpenNewAccountPage(driver);

	}

	@Test
	public void testOpenNewAccountWithValidation() {

		openNewAccount.navigateToOpenAccountPage();

		openNewAccount.selectAccountType("CHECKING");
		openNewAccount.fromAccountDropdown.click();

		Select fromAccountSelect = new Select(openNewAccount.fromAccountDropdown);
		fromAccountSelect.selectByIndex(0); // Select the first available account

		openNewAccount.submitButton.click();

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement accountIdElement = wait.until(ExpectedConditions.visibilityOf(openNewAccount.newAccountId));
		String newaccountnum = accountIdElement.getText();

		System.out.println("new account num is:" + newaccountnum);
		Assert.assertNotNull(newaccountnum, "New Account ID should not be null");

	}

	@Test
	public void verifyTheCreatedAccountVisiblieInAccountOverview() {

		// creating new Account
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement accountIdElement = wait.until(ExpectedConditions.visibilityOf(openNewAccount.newAccountId));
		String newaccountnum = accountIdElement.getText();

		// Navigate to AccountOverviewLink
		openNewAccount.accountsOverviewLink.click();

		// Step 3: Wait until the overview table loads
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("accountTable"))); // replace with actual ID

		// Step 4: Find all account number entries in the overview table
		List<WebElement> accountElements = driver.findElements(By.xpath("//table[@id='accountTable']//a")); // adjust
																											// XPath to
																											// match the
																											// table

		boolean accountFound = false;
		for (WebElement account : accountElements) {
			if (account.getText().trim().equals(newaccountnum.trim())) {
				accountFound = true;
				break;
			} else {
				System.out.println("new accountnum is not visible in a table");
			}
		}

	}

	@AfterClass
	public void closinBrowser() {
		closeEntireBrowser();
	}

}
