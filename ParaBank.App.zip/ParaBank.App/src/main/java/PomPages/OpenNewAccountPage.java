package PomPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class OpenNewAccountPage {

	WebDriver driver;

	// Constructor

	public OpenNewAccountPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// WebElements
	@FindBy(linkText = "Open New Account")
	WebElement openNewAccountLink;

	@FindBy(id = "type")
	WebElement accountTypeDropdown;

	@FindBy(id = "fromAccountId")
	public WebElement fromAccountDropdown;

	@FindBy(xpath = "//input[@value='Open New Account']")
	public WebElement submitButton;

	@FindBy(xpath = "//h1[text()='Account Opened!']")
	public WebElement accountOpenedMessage;

	@FindBy(xpath = "//a[@id='newAccountId']")
	public WebElement newAccountId;

	@FindBy(linkText = "Accounts Overview")
	public WebElement accountsOverviewLink;

	// Methods
	public void navigateToOpenAccountPage() {
		openNewAccountLink.click();
	}

	public void selectAccountType(String type) {
		new Select(accountTypeDropdown).selectByVisibleText(type);
	}

	public void submitNewAccount() {
		submitButton.click();
	}

//	public String getNewAccountId() {
//		return newAccountId.getText();
//	}
}