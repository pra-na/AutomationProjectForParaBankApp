package PomPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AccountServicesPage {
	WebDriver driver;

	// Constructor creation
	public AccountServicesPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// WebElements
	@FindBy(className = "title")
	public WebElement AccountsOverviewTitle;

	@FindBy(linkText = "Open New Account")
	public WebElement openNewAccountLink;

	@FindBy(linkText = "Accounts Overview")
	public WebElement accountsOverviewLink;

	@FindBy(linkText = "Transfer Funds")
	public WebElement transferFundsLink;

	@FindBy(linkText = "Bill Pay")
	private WebElement billPayLink;

	@FindBy(linkText = "Find Transactions")
	private WebElement findTransactionsLink;

	@FindBy(linkText = "Update Contact Info")
	private WebElement updateContactInfoLink;

	@FindBy(linkText = "Request Loan")
	private WebElement requestLoanLink;

	@FindBy(linkText = "Log Out")
	private WebElement logoutLink;

	// Methods
	public void clickOpenNewAccount() {
		openNewAccountLink.click();
	}

	public void clickAccountsOverview() {
		accountsOverviewLink.click();
	}

	public void clickTransferFunds() {
		transferFundsLink.click();
	}

	public void clickBillPay() {
		billPayLink.click();
	}

	public void clickFindTransactions() {
		findTransactionsLink.click();
	}

}
