package PomPages;

import PomPages.OpenNewAccountPage;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AccountsOverviewPage {

	WebDriver driver;

	// Constructor creation
	public AccountsOverviewPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// WebElements
	@FindBy(id = "accountTable")
	public WebElement accountTable;

	@FindBy(linkText = "Accounts Overview")
	public WebElement accountsOverviewLink;

	// Methods

	public void printAccountDetails() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Accounts Overview"))).click();

		// Find all tables on the page
		WebDriverWait waitt = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Wait until the table has at least one clickable account link
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@id='accountTable']//a")));

		WebElement accountTable = driver.findElement(By.id("accountTable"));
		List<WebElement> rows = accountTable.findElements(By.tagName("tr"));
		System.out.println("Total rows in table: " + rows.size());

		for (int i = 1; i < rows.size(); i++) { // skip header
			List<WebElement> cells = rows.get(i).findElements(By.tagName("td"));

			// Check if this row has an <a> tag in the first <td>
			if (cells.size() >= 3) {
				try {
					WebElement accountLink = cells.get(0).findElement(By.tagName("a"));
					String accountId = accountLink.getText().trim();
					String balance = cells.get(1).getText().trim();
					String available = cells.get(2).getText().trim();

					System.out.println(
							"Account ID: " + accountId + ", Balance: " + balance + ", Available: " + available);
				} catch (NoSuchElementException e) {
					System.out.println("Skipping non-account row: " + rows.get(i).getText());
				}
			}
		}
	}
}
