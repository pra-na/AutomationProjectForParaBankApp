package PomPages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TransferFundsPage {

	WebDriver driver;

	// Constructor
	public TransferFundsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// WebElements
	@FindBy(linkText = "Transfer Funds")
	public WebElement transferFundsLink;

	@FindBy(id = "amount")
	public WebElement amountField;

	@FindBy(id = "fromAccountId")
	public WebElement fromAccountDropdown;

	@FindBy(id = "toAccountId")
	public WebElement toAccountDropdown;

	@FindBy(xpath = "//input[@value='Transfer']")
	public WebElement transferButton;

	@FindBy(id = "showResult")
	public WebElement successMessage;

	@FindBy(id = "amount")
	public WebElement transferAmount;

	@FindBy(id = "showError")
	public WebElement errorMessage;

	// Methods
	public void enterAmount(String amount) {
		amountField.clear();
		amountField.sendKeys(amount);
	}

	public void selectFromAccount(String accountId) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(fromAccountDropdown));
		Select fromSelect = new Select(fromAccountDropdown);
		fromSelect.selectByVisibleText(accountId);
	}

	public void selectToAccount(String accountId) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(toAccountDropdown));
		Select toSelect = new Select(toAccountDropdown);
		toSelect.selectByVisibleText(accountId);
	}

	public void clickTransferButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(transferButton)).click();
	}

	public String getSuccessMessage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		return wait.until(ExpectedConditions.visibilityOf(successMessage)).getText();
	}

	public String getErrorMessage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		return wait.until(ExpectedConditions.visibilityOf(errorMessage)).getText();

	}
}
